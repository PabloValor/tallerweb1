package tallerweb.sanguchetto.modelo;

import org.junit.Test;

public class SanguchettoTest {

    @Test
    public void testVaciar() {
        // Implementar
    }

    @Test
    public void testAgregarIngrediente() {
        // Implementar
    }

    @Test
    public void testVerIngredientes() {
        // Implementar
    }

    @Test
    public void testVerCondimentos() {
        // Implementar
    }

    @Test
    public void testGetPrecio() {
        // Implementar
    }
}
